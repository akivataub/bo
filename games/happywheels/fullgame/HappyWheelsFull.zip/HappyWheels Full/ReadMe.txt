         Full Version of HappyWheels v1.70
              --// Thanks SnakY \\--

Cracked By SnakY,

2 days later, I get a reply from swfnerd. "Oh, that SWF also uses php scripts to 
get different data, like available levels, that's not good - 
I should fake that script request to make SWF run locally."

1 week later, he gives me the download link. He told me,

"Replays and some other functionality will not be available too, since 
it require original server 
(replays are saved to the server and loaded from it using php scripts)."

I asked swfnerd if I could release it, he said it was ok.
So here I am, you're reading my ReadMe.txt


--// How to run HappyWheels v1.70 \\--

1. Extract "HWFull.rar" with WinRAR

2. Drag "Happy-Wheels.swf" to "flashplayer_11_sa.exe"

3. Have Fun!

Game Happy-Wheels ONLINE:

http://www.totaljerkface.com/happy_wheels.php

--//THANKS SNAKY\\--



